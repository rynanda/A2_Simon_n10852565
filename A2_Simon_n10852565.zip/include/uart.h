
// Function prototypes for UART initialisation and printing to UART
void uart_init(void);
void uart_putc(char c);
void uart_puts(char* string);