
#include <avr/io.h>

extern volatile uint16_t count;

void timer_init(void);