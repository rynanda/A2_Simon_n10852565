
// 1ms counter variable to be used in Simon.c
extern volatile uint16_t count;

// Function prototype for TCB0 timer initialisation
void timer_init(void);