
/* Function prototype to initialise 
analogue to digital converter for potentiometer */
void adc_init(void);
