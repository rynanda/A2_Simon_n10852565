
void adc_init(void);