
// Include headers
#include <stdint.h>

// Function prototypes for SPI initialisation and displaying to 7-segment display
void spi_init(void);
void spi_write(uint8_t b);