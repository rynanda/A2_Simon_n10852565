
// Function prototype for pulse width modulation initialisation
void pwm_init(void);
